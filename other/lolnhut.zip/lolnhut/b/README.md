# Project Công nghệ và Dịch vụ Web (CT313H)

#### Backend

Học kỳ 1, Năm học 2023-2024

**MSSV 1** : B2005889

**Họ tên SV 1**: Hồ Minh Nhựt

**MSSV 2**: B2005843

**Họ tên SV 2**: Nguyễn Duy Khang

**Lớp học phần**: M02

**Tên dự án**: Quản lý truyện

---

After pulling the backend code

- npm install --save
- npm i knex mysql
- npm i express-session 